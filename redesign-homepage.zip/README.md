
  # Redesign Arcade Homepage

  This is a code bundle for Redesign Arcade Homepage. The original project is available at https://www.figma.com/design/44o3phySraEpU5Y75sHuzh/Redesign-Arcade-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  